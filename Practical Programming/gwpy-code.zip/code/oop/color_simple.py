class Color(object):
    '''An RGB color, with red, green and blue components.'''
    pass
