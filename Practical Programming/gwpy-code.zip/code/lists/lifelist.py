[['Canada', 76.5], ['United States', 75.5], ['Mexico', 72.0]]
