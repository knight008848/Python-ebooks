def mergesort(L):
    """Sort L in increasing order."""
