def find_two_smallest(L):
    '''Return a tuple of the indices of the two smallest values in list L.'''
    sort a copy of L
    get the two smallest numbers
    find their indices in the original list L
    return the two indices
