def find_two_smallest(L):
    '''Return a tuple of the indices of the two smallest values in list L.'''
    
    find the index of the minimum element in L
    remove that element from the list
    find the index of the new minimum element in the list
    return the two indices
