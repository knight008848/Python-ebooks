>>> def f():
...     return 3
...
>>> f()
3
