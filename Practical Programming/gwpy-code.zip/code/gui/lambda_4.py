>>> (lambda x: 2 * x)(3)
6
