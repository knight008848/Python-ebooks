from Tkinter import *
window = Tk()
label = Label(window, text="This is our label.")
label.pack()
