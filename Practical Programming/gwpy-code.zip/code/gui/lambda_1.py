>>> lambda: 3
<function <lambda> at 0x00A89B30>
>>> (lambda: 3)()
3
