>>> f = lambda(): 3
>>> f()
3
