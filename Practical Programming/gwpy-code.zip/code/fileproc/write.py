output_file = open("test.txt", "w")
output_file.write("Computer Science")
output_file.close()