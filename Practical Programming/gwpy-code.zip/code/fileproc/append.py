output_file = open("test.txt", "a")
ouput_file.write("Software Engineering")
output_file.close()