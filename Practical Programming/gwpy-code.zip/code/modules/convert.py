def to_celsius(t):                        
    return (t - 32.0) * 5.0 / 9.0
