def above_freezing(t):
    return t > 0
