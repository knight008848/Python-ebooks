if __name__ == "__main__":
    print "I am the main program"
else:
    print "Someone is importing me"
