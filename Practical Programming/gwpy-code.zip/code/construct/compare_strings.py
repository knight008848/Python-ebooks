if my_compare('abc', 'def') == -1:
    print 'success'
else:
    print 'failure'
