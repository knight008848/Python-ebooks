def square(num):
    """ (number) -> number
    
    Return the square of num.

    >>> square(3)
    9
    """
