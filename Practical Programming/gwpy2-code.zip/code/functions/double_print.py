def print_double_num(x):
    """ (number) -> NoneType

    Double x.

    >>> double_num(3)
    """
    
    print(x * 2)