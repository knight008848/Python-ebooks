open('data/data1.txt', 'r')
open('../data1.txt', 'r')
open('../../../data/data1.txt', 'r')
