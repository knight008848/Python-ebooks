with open('topics.txt', 'w') as output_file:
    output_file.write('Computer Science')
