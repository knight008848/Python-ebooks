print("The panda's scientific name is 'Ailuropoda melanoleuca'")
